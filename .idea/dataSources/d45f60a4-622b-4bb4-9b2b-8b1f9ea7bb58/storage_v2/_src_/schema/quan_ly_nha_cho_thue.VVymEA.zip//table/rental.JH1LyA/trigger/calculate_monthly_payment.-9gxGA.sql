create definer = root@localhost trigger calculate_monthly_payment
    before insert
    on rental
    for each row
BEGIN
    DECLARE total_cost FLOAT;
    SELECT electricity_cost + water_cost + room_cost INTO total_cost FROM House WHERE house_id = NEW.house_id;
    SET NEW.monthly_payment = total_cost;
END;

